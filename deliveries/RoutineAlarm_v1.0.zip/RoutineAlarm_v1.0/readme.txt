1. download MS .Net runtime package and install
	site: https://dotnet.microsoft.com/en-us/download/dotnet/8.0
		x64: https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/runtime-desktop-8.0.7-windows-x64-installer
		x32: https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/runtime-desktop-8.0.7-windows-x86-installer
2. enter to installation folder, run script auto_install.bat, it will:
	- create shorcut in Windows startup folder
	- create shortcut in root folder
2. start the application from shortcut created in outside folder

